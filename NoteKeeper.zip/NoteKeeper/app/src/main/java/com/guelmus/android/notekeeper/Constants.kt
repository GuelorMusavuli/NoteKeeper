package com.guelmus.android.notekeeper

const val NOTE_POSITION = "EXTRA_NOTE_POSITION"
const val POSITION_NOT_SET = -1