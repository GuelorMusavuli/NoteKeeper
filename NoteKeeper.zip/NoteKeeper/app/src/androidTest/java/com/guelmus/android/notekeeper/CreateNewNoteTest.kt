//package com.guelmus.android.notekeeper
//
//import androidx.test.ext.junit.runners.AndroidJUnit4
//import androidx.test.runner.AndroidJUnitRunner
//import org.junit.Assert.*
//import org.junit.Test
//import org.junit.runner.RunWith
//import org.junit.runners.JUnit4
//import androidx.test.espresso.Espresso.*
//import androidx.test.espresso.matcher.ViewMatchers.*
//import org.hamcrest.Matchers.*
//import androidx.test.espresso.action.ViewActions.*
//import androidx.test.ext.junit.rules.ActivityScenarioRule
//import org.junit.Rule
//
//
//
//@RunWith(AndroidJUnit4::class)
//class CreateNewNoteTest{
//
//    //Ensure that NoteListActivity is up and running
//    val noteListActivity = ActivityScenarioRule(MainActivity::class.java)
//
//    /**
//     * Test case to verify that the app properly handling the creation of the new note
//     * */
//    @Test
//    fun createNewNote(){
//
//    }
//}

package com.jwhh.notekeeper

import android.support.test.runner.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import android.support.test.espresso.Espresso.*
import android.support.test.espresso.matcher.ViewMatchers.*
import org.hamcrest.Matchers.*
import android.support.test.espresso.action.ViewActions.*
import android.support.test.rule.ActivityTestRule
import org.junit.Rule
import android.support.test.espresso.Espresso.pressBack
import android.support.test.espresso.action.ViewActions.closeSoftKeyboard

@RunWith(AndroidJUnit4::class)
class CreateNewNoteTest{
    @Rule @JvmField
    val noteListActivity = ActivityTestRule(NoteListActivity::class.java)

    @Test
    fun createNewNote() {
        val noteTitle = "Test note title"
        val noteText = "This is the body of our test note"

        onView(withId(R.id.fab)).perform(click())

        onView(withId(R.id.textNoteTitle)).perform(typeText(noteTitle))
        onView(withId(R.id.textNoteText)).perform(typeText(noteText), closeSoftKeyboard())

    }
}